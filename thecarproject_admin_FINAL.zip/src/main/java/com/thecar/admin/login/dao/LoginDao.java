package com.thecar.admin.login.dao;

import com.thecar.admin.login.vo.LoginVO;

public interface LoginDao {
	
	public LoginVO adminLoginSelect(LoginVO lvo);

}
